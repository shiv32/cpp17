#include "pdfrenderer.h"
#include <fpdf_doc.h>
#include <fpdf_render.h>
#include <fpdfview.h>
#include <QDebug>
#include <QFile>

PdfRenderer::PdfRenderer(QObject* parent) : QObject(parent) {
  FPDF_InitLibrary();
}

QImage PdfRenderer::image() const { return m_image; }

void PdfRenderer::loadPdf(const QString& path) {
  QByteArray pathUtf8 = path.toUtf8();
  FPDF_DOCUMENT doc = FPDF_LoadDocument(pathUtf8.constData(), nullptr);
  if (!doc) {
    qWarning() << "Failed to load PDF";
    return;
  }

  FPDF_PAGE page = FPDF_LoadPage(doc, 0);
  if (!page) {
    FPDF_CloseDocument(doc);
    qWarning() << "Failed to load page";
    return;
  }

  int width = static_cast<int>(FPDF_GetPageWidth(page));
  int height = static_cast<int>(FPDF_GetPageHeight(page));
  int stride = width * 4;

  std::vector<uint8_t> buffer(stride * height, 255);

  FPDF_BITMAP bitmap = FPDFBitmap_CreateEx(width, height, FPDFBitmap_BGRA,
                                           buffer.data(), stride);
  FPDFBitmap_FillRect(bitmap, 0, 0, width, height, 0xFFFFFFFF);
  FPDF_RenderPageBitmap(bitmap, page, 0, 0, width, height, 0, 0);

  m_image =
      QImage(buffer.data(), width, height, stride, QImage::Format_RGBA8888)
          .copy();

  FPDFBitmap_Destroy(bitmap);
  FPDF_ClosePage(page);
  FPDF_CloseDocument(doc);

  emit imageChanged();
}
