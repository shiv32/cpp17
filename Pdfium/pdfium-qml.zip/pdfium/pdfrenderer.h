#pragma once
#include <QImage>
#include <QObject>

class PdfRenderer : public QObject {
  Q_OBJECT
  Q_PROPERTY(QImage image READ image NOTIFY imageChanged)

 public:
  explicit PdfRenderer(QObject* parent = nullptr);
  QImage image() const;

  Q_INVOKABLE void loadPdf(const QString& path);

 signals:
  void imageChanged();

 private:
  QImage m_image;
};
