#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "PdfImageProvider.h"
#include "pdfrenderer.h"

int main(int argc, char *argv[]) {
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
  QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

  QGuiApplication app(argc, argv);

  QQmlApplicationEngine engine;

  //--
  PdfRenderer renderer;
  renderer.loadPdf("sample.pdf");  // Load PDF here

  // Register image provider
  engine.addImageProvider("pdf", new PdfImageProvider(&renderer));

  // qmlRegisterType<PdfRenderer>("MyApp", 1, 0, "PdfRenderer");

  const QUrl url(QStringLiteral("qrc:/main.qml"));
  QObject::connect(&engine, &QQmlApplicationEngine::objectCreated, &app,
                   [url](QObject *obj, const QUrl &objUrl) {
                     if (!obj && url == objUrl) QCoreApplication::exit(-1);
                   },
                   Qt::QueuedConnection);
  engine.load(url);

  return app.exec();
}
