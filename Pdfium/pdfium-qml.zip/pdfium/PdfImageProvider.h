// pdfimageprovider.h
#pragma once
#include <QQuickImageProvider>
#include "pdfrenderer.h"

class PdfImageProvider : public QQuickImageProvider {
 public:
  PdfImageProvider(PdfRenderer* renderer)
      : QQuickImageProvider(QQuickImageProvider::Image), m_renderer(renderer) {}

  QImage requestImage(const QString& id, QSize* size, const QSize&) override {
    if (size) *size = m_renderer->image().size();
    return m_renderer->image();
  }

 private:
  PdfRenderer* m_renderer;
};
